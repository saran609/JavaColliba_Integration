package collibra.swagger.controller;

import java.util.Arrays;
import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class WelcomeController {

	// inject via application.properties
	@Value("${welcome.message}")
	private String message;

	@Value("${credentials}")
	private String credentials;

	@Autowired
	RestTemplate restTemplate;

	private List<String> tasks = Arrays.asList("a", "b", "c", "d", "e", "f", "g");

	@GetMapping("/")
	public String main(Model model) {
		model.addAttribute("message", message);
		model.addAttribute("tasks", tasks);

		return "welcome"; // view
	}

	// /hello?name=kotlin
	@GetMapping("/hello")
	public String mainWithParam(@RequestParam(name = "name", required = false, defaultValue = "") String name,
			Model model) {

		model.addAttribute("message", name);

		return "welcome"; // view
	}

	@GetMapping("/asset")
	public String getAssetDetails(@RequestParam(name = "assetId", required = false, defaultValue = "") String name,
			Model model) {
		
		byte[] plainCredsBytes = credentials.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);

		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		String response = restTemplate
				.exchange("https://vanguard-dev.collibra.com/rest/2.0/assets/"+name,
						HttpMethod.GET, entity, String.class)
				.getBody();

		model.addAttribute("message", response + " asset");

		return "welcome"; // view
	}

	@GetMapping("/domain")
	public String getDomainDetails(@RequestParam(name = "domainId", required = false, defaultValue = "") String name,
			Model model) {

		model.addAttribute("message", name + " domain");

		return "welcome"; // view
	}

	//http://localhost:9090/community?communityId=717f29f6-94ca-4a0d-a45c-943da4fc39aa
	@GetMapping("/community")
	public String getCommunityDetails(@RequestParam(name = "communityId", required = false, defaultValue = "") String name,
			Model model) {

		byte[] plainCredsBytes = credentials.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);

		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		String response = restTemplate
				.exchange("https://vanguard-dev.collibra.com/rest/2.0/communities/"+name,
						HttpMethod.GET, entity, String.class)
				.getBody();

		model.addAttribute("message", response + " community");

		return "welcome"; // view
	}

}
